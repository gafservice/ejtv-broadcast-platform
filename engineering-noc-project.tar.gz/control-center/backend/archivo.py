# código Python
